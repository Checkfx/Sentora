<?php
  $color_background="FFFFEE";
  $color_alt1 = "D8E6F0";
  $color_alt2 = "CED9FA";    
  $color_alt3 = "E5ECF4";  
  $color_alt4 = "C4CAE4";
?>