<?php
  $color_background="FAFAFA";
  $color_alt1 = "E4E4E4";
  $color_alt2 = "D9D9D9";
  $color_alt3 = "ECECEC";
  $color_alt4 = "CACACA";
?>