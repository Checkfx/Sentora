<?php
require_once("../admin_common.php");
validate_session($identity);
 
Header("Location: live.php");	
if(!($serversession))
  $mydatabase->close_connect();
 ?>