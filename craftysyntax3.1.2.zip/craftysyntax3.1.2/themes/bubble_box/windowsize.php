<?php
if(empty($winwidth)){ $winwidth = 600; }  
if(empty($winheight)){ $winheight = 450; }  
?>